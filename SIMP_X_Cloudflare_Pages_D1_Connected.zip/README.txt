SIMP X! — OFFLINE-FRIENDLY APPROVAL SYSTEM

WHAT IT DOES
- Visitors follow your WhatsApp channel.
- They submit their name and WhatsApp number. The request is saved in Netlify Blobs, so it remains there while you are offline.
- The visitor is sent to WhatsApp chat with you (08067918461) to attach their screenshot and include the request ID.
- You review the screenshot when available, then open /admin.html and approve the request.
- The admin panel generates a one-time access code. Send it privately to the visitor.
- The visitor enters the code on SIMP X!; the server validates and redeems it.

IMPORTANT LIMITATIONS
- WhatsApp does not provide ordinary websites with a public API to verify channel followers. This system does NOT claim to automatically check membership. The admin reviews proof.
- This needs a Netlify deployment with Functions and Netlify Blobs enabled. It will NOT work by opening index.html directly or by hosting as plain static files without the functions.
- One-time access is validated server-side. After a visitor redeems the code, it cannot be used again.
- Netlify Blobs persists the request queue while you are offline.

DEPLOYMENT
1. Extract this ZIP.
2. Deploy the entire contents of the simp_x_site folder to Netlify (not just index.html). Keep the netlify/functions folder and package.json.
3. In Netlify: Site configuration → Environment variables, add:
   ADMIN_SECRET = a long private password you create. Do not share it with visitors.
4. Trigger a fresh deploy after adding the environment variable.
5. Open https://YOUR-SITE.netlify.app/admin.html and enter the ADMIN_SECRET to review requests.
6. Visitor request WhatsApp destination is configured in index.html as 2348067918461 (your number 08067918461). If you change your number, update adminWhatsApp in index.html.
7. Make sure Netlify Functions and Blobs are available for your site plan/account.

ADMIN WORKFLOW
- Visitor submits request; Netlify saves it immediately.
- Visitor sends screenshot to WhatsApp and includes the generated request ID.
- You can be offline. Requests stay in the hosted database.
- When you return, open /admin.html, load requests, approve only after reviewing proof, then send the displayed code privately.
- Codes are one-time and should be sent only to the matching visitor.

DESIGN
Your SIMP X! dark theme, loading intro, rain overlay, music, and device sensitivity generator are retained.

VISUAL UPDATE
The page background now uses the dark forest-green gradient, soft green ambient glow, subtle grid, and slowly drifting translucent SIMP X! watermark words inspired by the supplied reference screenshot. The motion is slow and gentle (not shaking).
