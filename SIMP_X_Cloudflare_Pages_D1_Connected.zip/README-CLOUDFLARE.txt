SIMP X! — CLOUDFLARE PAGES VERSION
==================================

This package replaces the Netlify Functions + Netlify Blobs backend with
Cloudflare Pages Functions + Cloudflare D1. The original visual website,
music, device sensitivity interface, channel proof flow and admin page are
retained.

IMPORTANT: Do NOT use Cloudflare's simple drag-and-drop static upload for
this package. That static upload path does not deploy Pages Functions.
Use a Git-connected Cloudflare Pages project so the /functions folder is
built and deployed, or use Wrangler from a computer.

SETUP
-----

1. Create a GitHub repository and upload the CONTENTS of this folder
   (index.html, admin.html, functions/, schema.sql, wrangler.toml, and
   simp-x-theme.mp3) to the repository root.

2. In Cloudflare, open Workers & Pages > Create application > Pages >
   Connect to Git, choose that repository, and deploy.
   Framework preset: None
   Build command: leave blank
   Build output directory: /

3. Create a D1 database:
   Cloudflare dashboard > Storage & databases > D1 SQL Database >
   Create database. Name it simpx-db.

4. Open the new D1 database's Console and run the complete contents of
   schema.sql once.

5. Open Workers & Pages > your Pages project > Settings > Functions >
   D1 database bindings. Add:
     Variable name: DB
     D1 database: simpx-db
   Save, then trigger a new deployment.

6. In the Pages project's Settings > Variables and Secrets, add a secret:
     Name: SIMP_X_ADMIN_SECRET
     Value: create a long private password.
   Save, then trigger another deployment if Cloudflare asks.

7. Test the live site:
   - Open / and submit a test request.
   - Open /admin.html and enter the SIMP_X_ADMIN_SECRET.
   - Confirm the test request appears.
   - Approve only after checking the visitor's WhatsApp proof.
   - Redeem the one-time code on the main site.

SECURITY / DATA
---------------
- Keep SIMP_X_ADMIN_SECRET private. Do not place it in index.html or share it.
- D1 is a NEW database. Existing requests in Netlify Blobs are not copied
  automatically. Keep the old Netlify site and its data untouched until
  the Cloudflare version has passed testing.
- The WhatsApp channel follow is NOT automatically verified. Review proof
  manually, as in the previous version.
- This package uses Cloudflare Pages Functions. It must be deployed through
  Git integration or Wrangler; static drag-and-drop alone is insufficient.

API ROUTES
----------
POST /api/request-access
GET  /api/admin-requests   (requires x-admin-secret header)
POST /api/approve-request  (requires x-admin-secret header)
POST /api/redeem-code
